Track the current agent metadata work in `~/code/agents`.

Scope:
- Fix Codex pane detection (broken on macOS because process-name detection used truncated `ps -o comm` output)
- Persist and display active model for all agents
- Fix Claude regressions where `/rename` did not update dashboard title and `contextTokens/contextMax` were missing
- Fix Pi false idle/done reporting during active runs
- Add proper Codex hook-based reporting instead of scanner-only inference

Implemented / verified so far:
- Switched detection to use full process args instead of only `comm`, which fixes wrapped/vendor Codex binaries
- Added `model` persistence through `agents report` / state files and surfaced it in the UI
- Added `externalSessionId` to state so Claude pane sessions can map to Claude transcript JSONL files
- Scanner now resolves Claude renamed titles by reading the latest `/rename` `local_command` from `~/.claude/projects/.../<session>.jsonl`
- Added fallback inference for `contextTokens/contextMax` from pane footer content for Claude/Pi when state is missing them
- Fixed Pi extension state transitions in `extensions/pi/dustbot-reporting.ts`:
  - `turn_end` no longer reports `idle`
  - normal `tool_call` now reports `working`
  - `session_compact` now reports `working` instead of `idle`
  - only `agent_end` / `session_shutdown` should report idle
- Added Codex hook integration using Codex's documented `hooks.json` support:
  - new scripts in `extensions/codex/report-state.sh` and `extensions/codex/stop-hook.sh`
  - `agents setup` now patches `~/.codex/config.toml` to enable `[features] codex_hooks = true`
  - `agents setup` now merges our hook entries into `~/.codex/hooks.json`
  - fixed the installed `~/.codex/hooks.json` shape to the actual Codex format with a top-level `hooks` object; the earlier top-level event-key shape was ignored by Codex, which explained why no Codex state files were appearing
  - Codex hooks report `idle` on `SessionStart`, `working` on `UserPromptSubmit` / `PreToolUse(Bash)` / `PostToolUse(Bash)`, and `question` vs `idle` on `Stop`
  - Codex hook reports include `--model` and `--external-session-id`
- Scanner now uses a hybrid Codex detector:
  - hook-backed state for `working` / `idle` / `question`
  - generic content fallback retained for approval prompts
  - disabled Codex screen-scrape question fallback when there is no hook state, because it was falsely matching older `?` text in completed output
- Added Codex footer context inference from `XX% left` using `~/.codex/models_cache.json`, which now surfaces values like `contextTokens: 85272` and `contextMax: 258400`
- `npm test` passes
- `npm run build` passes
- `node dist/cli.js setup --quiet` fixed the live Codex config in `~/.codex/config.toml` and `~/.codex/hooks.json`

Current task / next verification:
- Need to validate the corrected Codex hook wiring against a real interactive Codex pane in tmux.
- Specifically check whether `~/.agents/state/codex-*.json` files are created/updated during interactive use and whether `agents ls` now reflects hook-driven `working` / `idle` transitions.

Key files:
- `src/scanner.ts`
- `src/state.ts`
- `src/cli.ts`
- `src/setup.ts`
- `extensions/claude/state-hook.sh`
- `extensions/claude/stop-hook.sh`
- `extensions/pi/dustbot-reporting.ts`
- `extensions/codex/report-state.sh`
- `extensions/codex/stop-hook.sh`
- `src/scanner.test.ts`
- `src/components/AgentTable.tsx`
- `src/components/Dashboard.tsx`
- `AGENTS.md`

Nuances / open follow-up:
- Already-running Claude panes need another hook event before `externalSessionId` lands in state and transcript-backed rename starts working
- Claude footer parsing currently yields display strings like `Opus 4.6 (1M context)` and approximate token counts from percentage/footer text
- Codex approval still relies on screen-scrape fallback because Codex hooks do not expose a dedicated approval event
- Quick local experiments suggested `codex exec` may not trigger hooks the same way as the interactive TUI; current implementation is aimed at interactive Codex panes, which is what `agents` monitors
- If interactive Codex still does not emit hook state, likely next places to inspect are Codex config-layer loading/trust and the exact runtime `hooks.json` shape expectations
